package rs.ac.singidunum.sasacejic2016201948;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;

import java.lang.reflect.Field;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link AutomobiliFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link AutomobiliFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AutomobiliFragment extends Fragment{

    private final static String SHARED_PREFERENCES_PREFIX = "AutomobiliFragmentSharedPreferencesPrefix";

    private OnFragmentInteractionListener mListener;

    public AutomobiliFragment() {
    }

    public static AutomobiliFragment newInstance() {
        AutomobiliFragment fragment = new AutomobiliFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_automobili, container, false);

        LinearLayout automobiliScrollView = (LinearLayout) v.findViewById(R.id.automobiliScrollView);
        initAutomobili(inflater,automobiliScrollView);

        return v;
    }

    private void initAutomobili(final LayoutInflater inflater, final LinearLayout automobiliScrollView){
        AutomobilApi.getJSON("https://automobilli.000webhostapp.com/automobili.json",new ReadDataHandler(){
            @Override
            public void handleMessage(Message msg) {
                try {
                    JSONArray array = new JSONArray(getJson());
                    LinkedList<AutomobilModel> automobili = AutomobilModel.parseJSONArray(array);

                    SharedPreferences sharedPreferences = getContext().getSharedPreferences("FilterActivitySharedPreferencesPrefix",0);

                    final String marka = (sharedPreferences.getString("marka","sve marke")).trim();
                    final String klasa = (sharedPreferences.getString("klasa","sve klase")).trim();

                    if (marka.contains("sve marke") && klasa.contains("sve klase")) {
                        for(final AutomobilModel a:automobili){
                            final RelativeLayout item = (RelativeLayout) inflater.inflate(R.layout.automobil_view,null);

                            ((TextView) item.findViewById(R.id.labelMarkaModel)).setText(a.getMarka() + " " + a.getModel());
                            ((TextView) item.findViewById(R.id.labelDetalji)).setText("klasa: " + a.getKlasa() + "\n" + "cena: " + a.getCena());
                            ((ImageView) item.findViewById(R.id.imageAuto)).setImageResource(getResId(a.getSlika(),R.drawable.class));

                            item.setOnClickListener(new View.OnClickListener(){
                                @Override
                                public void onClick(View v){
                                    SharedPreferences sharedPreferences = getContext().getSharedPreferences(SHARED_PREFERENCES_PREFIX,0);
                                    SharedPreferences.Editor editor = sharedPreferences.edit();

                                    editor.putString("marka",a.getMarka());
                                    editor.putString("model",a.getModel());
                                    editor.putInt("broj_sedista",a.getBrojSedista());

                                    editor.commit();

                                    Intent i = new Intent(getContext(),IznajmljivanjeActivity.class);
                                    startActivity(i);
                                }
                            });

                            automobiliScrollView.addView(item);
                        }
                    }else if(!(marka.contains("sve marke")) && klasa.contains("sve klase")){
                        for(final AutomobilModel a:automobili){
                            if (a.getMarka().contains(marka)) {
                                RelativeLayout item = (RelativeLayout) inflater.inflate(R.layout.automobil_view,null);

                                ((TextView) item.findViewById(R.id.labelMarkaModel)).setText(a.getMarka() + " " + a.getModel());
                                ((TextView) item.findViewById(R.id.labelDetalji)).setText("klasa: " + a.getKlasa() + "\n" + "cena: " + a.getCena());
                                ((ImageView) item.findViewById(R.id.imageAuto)).setImageResource(getResId(a.getSlika(),R.drawable.class));

                                item.setOnClickListener(new View.OnClickListener(){
                                    @Override
                                    public void onClick(View v){
                                        SharedPreferences sharedPreferences = getContext().getSharedPreferences(SHARED_PREFERENCES_PREFIX,0);
                                        SharedPreferences.Editor editor = sharedPreferences.edit();

                                        editor.putString("marka",a.getMarka());
                                        editor.putString("model",a.getModel());
                                        editor.putInt("broj_sedista",a.getBrojSedista());

                                        editor.commit();

                                        Intent i = new Intent(getContext(),IznajmljivanjeActivity.class);
                                        startActivity(i);
                                    }
                                });

                                automobiliScrollView.addView(item);
                            }
                        }
                    }else if(marka.contains("sve marke") && !(klasa.contains("sve klase"))){
                        for(final AutomobilModel a:automobili){
                            if (a.getKlasa().contains(klasa)) {
                                RelativeLayout item = (RelativeLayout) inflater.inflate(R.layout.automobil_view,null);

                                ((TextView) item.findViewById(R.id.labelMarkaModel)).setText(a.getMarka() + " " + a.getModel());
                                ((TextView) item.findViewById(R.id.labelDetalji)).setText("klasa: " + a.getKlasa() + "\n" + "cena: " + a.getCena());
                                ((ImageView) item.findViewById(R.id.imageAuto)).setImageResource(getResId(a.getSlika(),R.drawable.class));

                                item.setOnClickListener(new View.OnClickListener(){
                                    @Override
                                    public void onClick(View v){
                                        SharedPreferences sharedPreferences = getContext().getSharedPreferences(SHARED_PREFERENCES_PREFIX,0);
                                        SharedPreferences.Editor editor = sharedPreferences.edit();

                                        editor.putString("marka",a.getMarka());
                                        editor.putString("model",a.getModel());
                                        editor.putInt("broj_sedista",a.getBrojSedista());

                                        editor.commit();

                                        Intent i = new Intent(getContext(),IznajmljivanjeActivity.class);
                                        startActivity(i);
                                    }
                                });

                                automobiliScrollView.addView(item);
                            }
                        }
                    }else{
                        for(final AutomobilModel a:automobili){
                            if (a.getMarka().contains(marka) && a.getKlasa().contains(klasa)) {
                                RelativeLayout item = (RelativeLayout) inflater.inflate(R.layout.automobil_view,null);

                                ((TextView) item.findViewById(R.id.labelMarkaModel)).setText(a.getMarka() + " " + a.getModel());
                                ((TextView) item.findViewById(R.id.labelDetalji)).setText("klasa: " + a.getKlasa() + "\n" + "cena: " + a.getCena());
                                ((ImageView) item.findViewById(R.id.imageAuto)).setImageResource(getResId(a.getSlika(),R.drawable.class));

                                item.setOnClickListener(new View.OnClickListener(){
                                    @Override
                                    public void onClick(View v){
                                        SharedPreferences sharedPreferences = getContext().getSharedPreferences(SHARED_PREFERENCES_PREFIX,0);
                                        SharedPreferences.Editor editor = sharedPreferences.edit();

                                        editor.putString("marka",a.getMarka());
                                        editor.putString("model",a.getModel());
                                        editor.putInt("broj_sedista",a.getBrojSedista());

                                        editor.commit();

                                        Intent i = new Intent(getContext(),IznajmljivanjeActivity.class);
                                        startActivity(i);
                                    }
                                });

                                automobiliScrollView.addView(item);
                            }
                        }
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
                automobiliScrollView.removeViewAt(0);
            }
        });

        TextView ucitavanje = (TextView) inflater.inflate(R.layout.ucitavanje_view,null);
        automobiliScrollView.addView(ucitavanje);
    }


    public static int getResId(String resName, Class<?> c) {

        try {
            Field idField = c.getDeclaredField(resName);
            return idField.getInt(idField);
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }


    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
//            throw new RuntimeException(context.toString() + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }
}
