package rs.ac.singidunum.sasacejic2016201948;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Message;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

public class IznajmljivanjeActivity extends AppCompatActivity  implements View.OnClickListener{


    DatePicker inputPocetak;
    DatePicker inputKraj;
    Spinner inputBrojPutnika;
    Button buttonRezervisi;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_iznajmljivanje);

        initComponents();

    }

    private void initComponents(){
        inputPocetak = findViewById(R.id.inputPocetak);
        inputKraj = findViewById(R.id.inputKraj);
        inputBrojPutnika = findViewById(R.id.inputBrojPutnika);
        buttonRezervisi = findViewById(R.id.buttonRezervisi);

        inputPocetak.setMinDate(new Date().getTime());
        inputKraj.setMinDate(new Date().getTime());

        SharedPreferences sharedPreferences1 = getSharedPreferences("AutomobiliFragmentSharedPreferencesPrefix",0);
        final int brojSedista = sharedPreferences1.getInt("broj_sedista",1);

        ArrayList<Integer> brojPutnikaList = new ArrayList<>();
        for(int i = 1; i <= brojSedista; i++){
            brojPutnikaList.add(i);
        }
        ArrayAdapter<Integer> adapter = new ArrayAdapter<>(this,R.layout.spinner_item,brojPutnikaList);
        inputBrojPutnika.setAdapter(adapter);

        final String marka = sharedPreferences1.getString("marka","");
        final String model = sharedPreferences1.getString("model","");


        buttonRezervisi.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.buttonRezervisi){
            final String pocetakRezervacije = String.format("%4d-%2d-%2d",inputPocetak.getYear(),inputPocetak.getMonth()+1,inputPocetak.getDayOfMonth());
            final String krajRezervacije = String.format("%4d-%2d-%2d",inputKraj.getYear(),inputKraj.getMonth()+1,inputKraj.getDayOfMonth());
            int brojPutnika = (int)inputBrojPutnika.getSelectedItem();


            if (proveriDatume(pocetakRezervacije,krajRezervacije) <= 0) {
                final SharedPreferences sharedPreferences = getSharedPreferences("MainActivitySharedPreferencesPrefix",0);

                String ime = sharedPreferences.getString("ime","");
                String prezime = sharedPreferences.getString("prezime","");
                String adresa = sharedPreferences.getString("adresa","");
                String telefon = sharedPreferences.getString("broj_telefona","");
                String email = sharedPreferences.getString("email","");

                SharedPreferences sharedPreferences1 = getSharedPreferences("AutomobiliFragmentSharedPreferencesPrefix",0);

                String marka = sharedPreferences1.getString("marka","");
                String model = sharedPreferences1.getString("model","");


                List<RezervacijaApi.Element> data = new ArrayList<>();
                data.add(new RezervacijaApi.Element("ime",ime));
                data.add(new RezervacijaApi.Element("prezime",prezime));
                data.add(new RezervacijaApi.Element("adresa",adresa));
                data.add(new RezervacijaApi.Element("broj_telefona",telefon));
                data.add(new RezervacijaApi.Element("email",email));
                data.add(new RezervacijaApi.Element("marka",marka));
                data.add(new RezervacijaApi.Element("model",model));
                data.add(new RezervacijaApi.Element("datum_pocetka",pocetakRezervacije));
                data.add(new RezervacijaApi.Element("datum_kraja",krajRezervacije));
                data.add(new RezervacijaApi.Element("broj_putnika",String.valueOf(brojPutnika)));


                RezervacijaApi.postDataJSON("https://automobilli.000webhostapp.com/rezervacije_service.php",data,new ReadDataHandler(){
                    @Override
                    public void handleMessage(Message msg) {
                        String json = getJson();

                        Intent i = new Intent(getApplicationContext(),PopupWindowActivity.class);

                        Bundle extras = new Bundle();

                        extras.putString("poruka",json);
                        i.putExtras(extras);

                        startActivity(i);
                    }
                });
            }else{
                Intent i = new Intent(getApplicationContext(),PopupWindowActivity.class);

                Bundle extras = new Bundle();

                extras.putString("poruka","Pogrešno ste uneli datum početka ili kraja korišćenja vozila!");
                i.putExtras(extras);

                startActivity(i);
            }
        }
    }

    private int proveriDatume(String datumPocetka, String datumKraja){

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

            Date pocetak = sdf.parse(datumPocetka);
            Date kraj = sdf.parse(datumKraja);

            Calendar c = Calendar.getInstance();

            int rezultat = pocetak.compareTo(kraj);
            return rezultat;

        } catch (ParseException e) {
            e.printStackTrace();
        }
        return 1;
    }

}
