package rs.ac.singidunum.sasacejic2016201948;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private final static String SHARED_PREFERENCES_PREFIX = "MainActivitySharedPreferencesPrefix";
    private final static String SHARED_PREFERENCES_IME = "ime";
    private final static String SHARED_PREFERENCES_PREZIME = "prezime";
    private final static String SHARED_PREFERENCES_ADRESA = "adresa";
    private final static String SHARED_PREFERENCES_BROJ_TELEFONA = "broj_telefona";
    private final static String SHARED_PREFERENCES_EMAIL = "email";

    EditText inputIme;
    EditText inputPrezime;
    EditText inputAdresa;
    EditText inputTelefon;
    EditText inputMail;
    Button buttonDalje;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initComponents();
    }

    private void initComponents(){
        inputIme = findViewById(R.id.inputIme);
        inputPrezime = findViewById(R.id.inputPrezime);
        inputAdresa = findViewById(R.id.inputAdresa);
        inputTelefon = findViewById(R.id.inputTelefon);
        inputMail = findViewById(R.id.inputMail);
        buttonDalje = findViewById(R.id.buttonDalje);

        procitajPodatke();

        buttonDalje.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.buttonDalje){
            String ime = inputIme.getText().toString();
            String prezime = inputPrezime.getText().toString();
            String adresa = inputAdresa.getText().toString();
            String telefon = inputTelefon.getText().toString();
            String mail = inputMail.getText().toString();

            if (proveriPodatke(ime,prezime,adresa,telefon,mail) == true) {
                Intent i = new Intent(this,FilterActivity.class);

                Bundle extras = new Bundle();

                extras.putString("ime",ime);
                extras.putString("prezime",prezime);
                extras.putString("adresa",adresa);
                extras.putString("telefon",telefon);
                extras.putString("mail",mail);

                i.putExtras(extras);
                startActivity(i);
            }else{
                Intent i = new Intent(this,PopupWindowActivity.class);

                Bundle extras = new Bundle();

                String poruka = "Pogrešno ste uneli podatke!";

                extras.putString("poruka",poruka);

                i.putExtras(extras);
                startActivity(i);
            }
        }
    }

    @Override
    protected void onStop() {
        super.onStop();

        sacuvajPodatke();
    }

    private void sacuvajPodatke(){
        String ime = inputIme.getText().toString();
        String prezime = inputPrezime.getText().toString();
        String adresa = inputAdresa.getText().toString();
        String telefon = inputTelefon.getText().toString();
        String mail = inputMail.getText().toString();

        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFERENCES_PREFIX,0);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString(SHARED_PREFERENCES_IME,ime);
        editor.putString(SHARED_PREFERENCES_PREZIME,prezime);
        editor.putString(SHARED_PREFERENCES_ADRESA,adresa);
        editor.putString(SHARED_PREFERENCES_BROJ_TELEFONA,telefon);
        editor.putString(SHARED_PREFERENCES_EMAIL,mail);

        editor.commit();
    }

    private void procitajPodatke(){
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFERENCES_PREFIX,0);

        String ime = sharedPreferences.getString(SHARED_PREFERENCES_IME,"");
        String prezime = sharedPreferences.getString(SHARED_PREFERENCES_PREZIME,"");
        String adresa = sharedPreferences.getString(SHARED_PREFERENCES_ADRESA,"");
        String telefon = sharedPreferences.getString(SHARED_PREFERENCES_BROJ_TELEFONA,"");
        String mail = sharedPreferences.getString(SHARED_PREFERENCES_EMAIL,"");

        inputIme.setText(ime);
        inputPrezime.setText(prezime);
        inputAdresa.setText(adresa);
        inputTelefon.setText(telefon);
        inputMail.setText(mail);
    }

    private boolean proveriPodatke(String ime, String prezime, String adresa, String telefon, String mail){
        ArrayList<String> unetiPodaci = new ArrayList<>();

        unetiPodaci.add(ime);
        unetiPodaci.add(prezime);
        unetiPodaci.add(adresa);
        unetiPodaci.add(telefon);
        unetiPodaci.add(mail);

        for(String parametar:unetiPodaci){
            if (parametar == null || parametar == ""){
                return false;
            }
        }

        if(!ime.matches("^[A-ZŠĐŽĆČ][a-zšđžćč]+$")){
            return false;
        }
        if(!prezime.matches("^[A-ZŠĐŽĆČ][a-zšđžćč]+(\\s|\\-)?([A-ZŠĐŽĆČ][a-zšđžćč]+)*$")){
            return false;
        }
        if(!adresa.matches("^([A-ZŠĐŽĆČa-zšđžćč]+\\s)+\\d+[a-z]?\\s?\\,\\s?[A-ZŠĐŽĆČ][a-zšđžćč]+(\\s[A-ZŠĐŽĆČ][a-zšđžćč]+)*$")){
            return false;
        }
        if(!telefon.matches("^\\+\\d{8,15}$")){
            return false;
        }
        if(!mail.matches("^[a-z\\.\\d]+\\@[a-z]+\\.[a-z]{2,5}$")){
            return false;
        }

        return true;
    }
}
