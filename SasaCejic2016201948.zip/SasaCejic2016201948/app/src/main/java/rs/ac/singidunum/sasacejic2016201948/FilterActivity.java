package rs.ac.singidunum.sasacejic2016201948;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class FilterActivity extends AppCompatActivity implements View.OnClickListener {
    private final static String SHARED_PREFERENCES_PREFIX = "FilterActivitySharedPreferencesPrefix";
    private final static String SHARED_PREFERENCES_MARKA = "marka";
    private final static String SHARED_PREFERENCES_KLASA = "klasa";

    Spinner inputMarka;
    Spinner inputKlasa;
    Button buttonPonuda;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filter);

        initComponents();
    }

    private void initComponents(){

        inputMarka = findViewById(R.id.inputMarka);
        inputKlasa = findViewById(R.id.inputKlasa);
        buttonPonuda = findViewById(R.id.buttonPonuda);

        ArrayList<String> markeList = new ArrayList<>();

        markeList.add("sve marke");
        markeList.add("Audi");
        markeList.add("Alfa Romeo");
        markeList.add("BMW");
        markeList.add("Citroen");
        markeList.add("Fiat");
        markeList.add("Folkswagen");
        markeList.add("Jaguar");
        markeList.add("Jeep");
        markeList.add("Kia");
        markeList.add("Mercedes");
        markeList.add("Opel");
        markeList.add("Peugeot");
        markeList.add("Smart");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,R.layout.spinner_item, markeList);
        inputMarka.setAdapter(adapter);

        ArrayList<String> klaseList = new ArrayList<>();

        klaseList.add("sve klase");
        klaseList.add("gradski");
        klaseList.add("limuzina");
        klaseList.add("karavan");
        klaseList.add("sport");
        klaseList.add("džip");

        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(this,R.layout.spinner_item,klaseList);
        inputKlasa.setAdapter(adapter1);

        procitajPodatke();

        buttonPonuda.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.buttonPonuda) {
            sacuvajPodatke();
            Intent i = new Intent(this,PrikazAutomobilaActivity.class);
            startActivity(i);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();

        sacuvajPodatke();
    }

    private void sacuvajPodatke(){
        String marka = inputMarka.getSelectedItem().toString();
        String klasa = inputKlasa.getSelectedItem().toString();

        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFERENCES_PREFIX,0);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString(SHARED_PREFERENCES_MARKA,marka);
        editor.putString(SHARED_PREFERENCES_KLASA,klasa);

        editor.commit();
    }

    private void procitajPodatke(){
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFERENCES_PREFIX,0);

        String marka = sharedPreferences.getString(SHARED_PREFERENCES_MARKA,"");
        String klasa = sharedPreferences.getString(SHARED_PREFERENCES_KLASA,"");

        inputMarka.setSelection(getIndex(inputMarka, marka));
        inputKlasa.setSelection(getIndex(inputKlasa, klasa));

    }

    private int getIndex(Spinner spinner, String myString){
        for (int i=0;i<spinner.getCount();i++){
            if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(myString)){
                return i;
            }
        }

        return 0;
    }
}
