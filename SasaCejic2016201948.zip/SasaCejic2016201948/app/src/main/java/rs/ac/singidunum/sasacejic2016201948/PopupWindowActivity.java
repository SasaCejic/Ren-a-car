package rs.ac.singidunum.sasacejic2016201948;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class PopupWindowActivity extends AppCompatActivity implements View.OnClickListener {
    TextView labelPoruka;
    Button buttonOK;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_popup_window);

        initComponents();
    }

    private void initComponents(){
        labelPoruka = findViewById(R.id.labelPoruka);
        buttonOK = findViewById(R.id.buttonOK);

        Bundle extras = getIntent().getExtras();
        String poruka = extras.getString("poruka");



        labelPoruka.setText(poruka);

        buttonOK.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.buttonOK){
            if (labelPoruka.getText().toString().contains("Rezervacija je uspešno poslata!")) {
                Intent i = new Intent(this,MainActivity.class);
                startActivity(i);
            }else{
                this.finish();
            }
        }
    }
}
