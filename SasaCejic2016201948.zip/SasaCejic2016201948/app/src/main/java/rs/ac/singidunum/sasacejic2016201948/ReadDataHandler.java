package rs.ac.singidunum.sasacejic2016201948;

import android.os.Handler;

public class ReadDataHandler extends Handler {
    private String json;

    public String getJson() {
        return json;
    }

    public void setJson(String json) {
        this.json = json;
    }
}
