package rs.ac.singidunum.sasacejic2016201948;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.LinkedList;

public class AutomobilModel {
    private String marka, model, klasa, cena, slika;
    int brojSedista;

    public AutomobilModel() {
    }

    public AutomobilModel(String marka, String model, String klasa, int brojSedista, String cena, String slika) {
        this.marka = marka;
        this.model = model;
        this.klasa = klasa;
        this.brojSedista = brojSedista;
        this.cena = cena;
        this.slika = slika;
    }

    public String getMarka() {
        return marka;
    }

    public void setMarka(String marka) {
        this.marka = marka;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getKlasa() {
        return klasa;
    }

    public void setKlasa(String klasa) {
        this.klasa = klasa;
    }

    public int getBrojSedista() {
        return brojSedista;
    }

    public void setBrojSedista(int brojSedista) {
        this.brojSedista = brojSedista;
    }

    public String getCena() {
        return cena;
    }

    public void setCena(String cena) {
        this.cena = cena;
    }

    public String getSlika() {
        return slika;
    }

    public void setSlika(String slika) {
        this.slika = slika;
    }

    public static AutomobilModel parseJSONObject(JSONObject object){
        AutomobilModel automobil = new AutomobilModel();
        try {
            if(object.has("marka")){
                automobil.setMarka(object.getString("marka"));
            }
            if(object.has("model")){
                automobil.setModel(object.getString("model"));
            }
            if(object.has("klasa")){
                automobil.setKlasa(object.getString("klasa"));
            }
            if(object.has("broj_sedista")){
                automobil.setBrojSedista(Integer.parseInt(object.getString("broj_sedista")));
            }
            if(object.has("cena")){
                automobil.setCena(object.getString("cena"));
            }
            if(object.has("slika")){
                automobil.setSlika(object.getString("slika"));
            }
        } catch (JSONException e) {
        }
        return automobil;
    }

    public static LinkedList<AutomobilModel> parseJSONArray(JSONArray array){
        LinkedList<AutomobilModel> list = new LinkedList<>();

        try {
            for (int i = 0; i < array.length(); i++) {
                list.add(parseJSONObject(array.getJSONObject(i)));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return list;
    }
}
