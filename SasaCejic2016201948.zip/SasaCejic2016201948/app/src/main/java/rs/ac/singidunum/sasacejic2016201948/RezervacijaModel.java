package rs.ac.singidunum.sasacejic2016201948;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.LinkedList;

public class RezervacijaModel {
    private String ime, prezime, adresa, brojTelefona, email, marka, model, datumPocetka, datumKraja;
    private int brojPutnika;

    public RezervacijaModel() {
    }

    public RezervacijaModel(String ime, String prezime, String adresa, String brojTelefona, String email, String marka, String model, String datumPocetka, String datumKraja, int brojPutnika) {
        this.ime = ime;
        this.prezime = prezime;
        this.adresa = adresa;
        this.brojTelefona = brojTelefona;
        this.email = email;
        this.marka = marka;
        this.model = model;
        this.datumPocetka = datumPocetka;
        this.datumKraja = datumKraja;
        this.brojPutnika = brojPutnika;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getAdresa() {
        return adresa;
    }

    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }

    public String getBrojTelefona() {
        return brojTelefona;
    }

    public void setBrojTelefona(String brojTelefona) {
        this.brojTelefona = brojTelefona;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMarka() {
        return marka;
    }

    public void setMarka(String marka) {
        this.marka = marka;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getDatumPocetka() {
        return datumPocetka;
    }

    public void setDatumPocetka(String datumPocetka) {
        this.datumPocetka = datumPocetka;
    }

    public String getDatumKraja() {
        return datumKraja;
    }

    public void setDatumKraja(String datumKraja) {
        this.datumKraja = datumKraja;
    }

    public int getBrojPutnika() {
        return brojPutnika;
    }

    public void setBrojPutnika(int brojPutnika) {
        this.brojPutnika = brojPutnika;
    }

    public static RezervacijaModel parseJSONObject(JSONObject object){
        RezervacijaModel rezervacija = new RezervacijaModel();
        try {
            if(object.has("ime")){
                rezervacija.setIme(object.getString("ime"));
            }
            if(object.has("prezime")){
                rezervacija.setPrezime(object.getString("prezime"));
            }
            if(object.has("adresa")){
                rezervacija.setAdresa(object.getString("adresa"));
            }
            if(object.has("broj_telefona")){
                rezervacija.setBrojTelefona(object.getString("broj_telefona"));
            }
            if(object.has("email")){
                rezervacija.setEmail(object.getString("email"));
            }
            if(object.has("marka")){
                rezervacija.setMarka(object.getString("marka"));
            }
            if(object.has("model")){
                rezervacija.setModel(object.getString("model"));
            }
            if(object.has("datum_pocetka")){
                rezervacija.setDatumPocetka(object.getString("datum_pocetka"));
            }
            if(object.has("datum_kraja")){
                rezervacija.setDatumKraja(object.getString("datum_kraja"));
            }
            if(object.has("broj_putnika")){
                rezervacija.setBrojPutnika(object.getInt("broj_putnika"));
            }

        } catch (JSONException e) {
        }
        return rezervacija;
    }

    public static LinkedList<RezervacijaModel> parseJSONArray(JSONArray array){
        LinkedList<RezervacijaModel> list = new LinkedList<>();

        try {
            for (int i = 0; i < array.length(); i++) {
                list.add(parseJSONObject(array.getJSONObject(i)));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public String toString() {
        return "RezervacijaModel{" +
                "ime='" + ime + '\'' +
                ", prezime='" + prezime + '\'' +
                ", adresa='" + adresa + '\'' +
                ", brojTelefona='" + brojTelefona + '\'' +
                ", email='" + email + '\'' +
                ", marka='" + marka + '\'' +
                ", model='" + model + '\'' +
                ", datumPocetka='" + datumPocetka + '\'' +
                ", datumKraja='" + datumKraja + '\'' +
                ", brojPutnika=" + brojPutnika +
                '}';
    }
}
